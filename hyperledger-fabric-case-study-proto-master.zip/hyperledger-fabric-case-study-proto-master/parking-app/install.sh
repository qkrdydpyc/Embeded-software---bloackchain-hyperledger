#!/bin/bash

npm install
node registerAdmin.js
node registerUser.js  
# npm run start
npm run start-dev
